var dir_68267d1309a1af8e8297ef4c3efbcdba =
[
    [ "main.c", "main_8c.html", "main_8c" ],
    [ "mappa.c", "mappa_8c.html", "mappa_8c" ],
    [ "menu.c", "menu_8c.html", "menu_8c" ],
    [ "ondata.c", "ondata_8c.html", "ondata_8c" ],
    [ "ostacoli.c", "ostacoli_8c.html", "ostacoli_8c" ],
    [ "player.c", "player_8c.html", "player_8c" ],
    [ "proiettili.c", "proiettili_8c.html", "proiettili_8c" ],
    [ "zombie.c", "zombie_8c.html", "zombie_8c" ]
];