var ondata_8c =
[
    [ "ALTEZZA", "ondata_8c.html#a737f1e0014465787871b62d0e61129d8", null ],
    [ "LARGHEZZA", "ondata_8c.html#accf70613e15dd3bcc231017b8f814c80", null ],
    [ "PROIETTILE_CHAR", "ondata_8c.html#ab868cca6903d959936689925bd18f478", null ],
    [ "TIMEOUT_VALUE", "ondata_8c.html#a244ef94c7189373fc6959985376688ab", null ],
    [ "VELOCITA_PROIETTILE", "ondata_8c.html#a867365e8704ef509bf175ea4381052d5", null ],
    [ "mostraInfoOndata", "ondata_8c.html#a92097ffe7b71e1638563eadd96033a65", null ],
    [ "mostraVittoria", "ondata_8c.html#ae190db7f89e123e4a11320300eefd270", null ]
];