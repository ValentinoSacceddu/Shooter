var zombie_8c =
[
    [ "ALTEZZA", "zombie_8c.html#a737f1e0014465787871b62d0e61129d8", null ],
    [ "LARGHEZZA", "zombie_8c.html#accf70613e15dd3bcc231017b8f814c80", null ],
    [ "PROIETTILE_CHAR", "zombie_8c.html#ab868cca6903d959936689925bd18f478", null ],
    [ "TIMEOUT_VALUE", "zombie_8c.html#a244ef94c7189373fc6959985376688ab", null ],
    [ "VELOCITA_PROIETTILE", "zombie_8c.html#a867365e8704ef509bf175ea4381052d5", null ],
    [ "controllaCollisioneZombie", "zombie_8c.html#ad0976b7acf9dd211235df5bc28f93213", null ],
    [ "controllaColpoZombie", "zombie_8c.html#a20bf547551b1e6762014f5570eaeb512", null ],
    [ "disegnaZombie", "zombie_8c.html#adb4a728714ba9354c3b62240e3e5558d", null ],
    [ "generaPosizioniZombie", "zombie_8c.html#a38e8d071b49de413e6a872d7d97590fd", null ],
    [ "gestisciCollisioni", "zombie_8c.html#ac378eef39f633c6ec30ef749a8435cd5", null ],
    [ "movimentoVersoTarget", "zombie_8c.html#a4e42be8620da8996c8ed3e62cc2288e1", null ],
    [ "muoviZombie", "zombie_8c.html#ae525bc4fc55fd75397ba39dbdd5c2fb2", null ],
    [ "ruotaZombie", "zombie_8c.html#a8dbb4f5d5363af886ee50609c45c02c1", null ]
];