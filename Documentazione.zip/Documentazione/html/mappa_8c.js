var mappa_8c =
[
    [ "ALTEZZA", "mappa_8c.html#a737f1e0014465787871b62d0e61129d8", null ],
    [ "LARGHEZZA", "mappa_8c.html#accf70613e15dd3bcc231017b8f814c80", null ],
    [ "PROIETTILE_CHAR", "mappa_8c.html#ab868cca6903d959936689925bd18f478", null ],
    [ "TIMEOUT_VALUE", "mappa_8c.html#a244ef94c7189373fc6959985376688ab", null ],
    [ "VELOCITA_PROIETTILE", "mappa_8c.html#a867365e8704ef509bf175ea4381052d5", null ],
    [ "confini", "mappa_8c.html#a8fb5ebf4d081188236825337bf110814", null ]
];