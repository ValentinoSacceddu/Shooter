var searchData=
[
  ['disattivaproiettili_0',['disattivaProiettili',['../proiettili_8c.html#a8a0d72aab1f12bc292c7d7fb51f6ee8f',1,'proiettili.c']]],
  ['disegnacasa_1',['disegnaCasa',['../ostacoli_8c.html#adc80ef3ea3bbb2283db14a232dca04f5',1,'ostacoli.c']]],
  ['disegnacasaplayer_2',['disegnaCasaPlayer',['../ostacoli_8c.html#a4711ac1e8b2dd54cc4a0976f61d51c12',1,'ostacoli.c']]],
  ['disegnamenu_3',['disegnaMenu',['../menu_8c.html#a8b242ccd86b9e1e347fb62f3eba443d8',1,'menu.c']]],
  ['disegnaostacoli_4',['disegnaOstacoli',['../ostacoli_8c.html#a045ec4d4d3dc0533ed05699109bea03e',1,'ostacoli.c']]],
  ['disegnaplayer_5',['disegnaPlayer',['../player_8c.html#a4e0bb83f1aa7841d4575d9b57c1a739e',1,'player.c']]],
  ['disegnaproiettili_6',['disegnaProiettili',['../proiettili_8c.html#ae0edcdab301b360f5072f6a7338c94b2',1,'proiettili.c']]],
  ['disegnazombie_7',['disegnaZombie',['../zombie_8c.html#adb4a728714ba9354c3b62240e3e5558d',1,'zombie.c']]]
];
