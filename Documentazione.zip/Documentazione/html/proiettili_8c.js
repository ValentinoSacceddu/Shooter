var proiettili_8c =
[
    [ "ALTEZZA", "proiettili_8c.html#a737f1e0014465787871b62d0e61129d8", null ],
    [ "LARGHEZZA", "proiettili_8c.html#accf70613e15dd3bcc231017b8f814c80", null ],
    [ "PROIETTILE_CHAR", "proiettili_8c.html#ab868cca6903d959936689925bd18f478", null ],
    [ "TIMEOUT_VALUE", "proiettili_8c.html#a244ef94c7189373fc6959985376688ab", null ],
    [ "VELOCITA_PROIETTILE", "proiettili_8c.html#a867365e8704ef509bf175ea4381052d5", null ],
    [ "aggiungiProiettile", "proiettili_8c.html#af0e34fdb5588b5660ccbe030f0533bb2", null ],
    [ "creaProiettile", "proiettili_8c.html#ae4bf5c1422fe8702bd81cdb2c4d67ed7", null ],
    [ "disattivaProiettili", "proiettili_8c.html#a8a0d72aab1f12bc292c7d7fb51f6ee8f", null ],
    [ "disegnaProiettili", "proiettili_8c.html#ae0edcdab301b360f5072f6a7338c94b2", null ],
    [ "liberaListaProiettili", "proiettili_8c.html#a3f567b2c0f0b595010d8732994765872", null ],
    [ "muoviProiettili", "proiettili_8c.html#a39b673e036c9b589565a20dc8dd945e8", null ]
];