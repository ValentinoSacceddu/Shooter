var searchData=
[
  ['player_2ec_0',['player.c',['../player_8c.html',1,'']]],
  ['proiettili_2ec_1',['proiettili.c',['../proiettili_8c.html',1,'']]]
];
