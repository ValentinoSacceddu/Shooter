var searchData=
[
  ['confini_0',['confini',['../mappa_8c.html#a8fb5ebf4d081188236825337bf110814',1,'mappa.c']]],
  ['controllacollisionezombie_1',['controllaCollisioneZombie',['../zombie_8c.html#ad0976b7acf9dd211235df5bc28f93213',1,'zombie.c']]],
  ['controllacolpozombie_2',['controllaColpoZombie',['../zombie_8c.html#a20bf547551b1e6762014f5570eaeb512',1,'zombie.c']]],
  ['creaproiettile_3',['creaProiettile',['../proiettili_8c.html#ae4bf5c1422fe8702bd81cdb2c4d67ed7',1,'proiettili.c']]]
];
