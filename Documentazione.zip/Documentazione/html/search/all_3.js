var searchData=
[
  ['generaposizionizombie_0',['generaPosizioniZombie',['../zombie_8c.html#a38e8d071b49de413e6a872d7d97590fd',1,'zombie.c']]],
  ['gestiscicollisioni_1',['gestisciCollisioni',['../zombie_8c.html#ac378eef39f633c6ec30ef749a8435cd5',1,'zombie.c']]]
];
