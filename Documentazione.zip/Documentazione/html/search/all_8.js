var searchData=
[
  ['ruotazombie_0',['ruotaZombie',['../zombie_8c.html#a8dbb4f5d5363af886ee50609c45c02c1',1,'zombie.c']]]
];
