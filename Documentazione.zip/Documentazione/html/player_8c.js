var player_8c =
[
    [ "ALTEZZA", "player_8c.html#a737f1e0014465787871b62d0e61129d8", null ],
    [ "LARGHEZZA", "player_8c.html#accf70613e15dd3bcc231017b8f814c80", null ],
    [ "PROIETTILE_CHAR", "player_8c.html#ab868cca6903d959936689925bd18f478", null ],
    [ "TIMEOUT_VALUE", "player_8c.html#a244ef94c7189373fc6959985376688ab", null ],
    [ "VELOCITA_PROIETTILE", "player_8c.html#a867365e8704ef509bf175ea4381052d5", null ],
    [ "disegnaPlayer", "player_8c.html#a4e0bb83f1aa7841d4575d9b57c1a739e", null ],
    [ "muoviPlayer", "player_8c.html#a41f624a5ccdbc09025de44dbd3a59c5d", null ]
];