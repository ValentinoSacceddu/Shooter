var menu_8c =
[
    [ "ALTEZZA", "menu_8c.html#a737f1e0014465787871b62d0e61129d8", null ],
    [ "LARGHEZZA", "menu_8c.html#accf70613e15dd3bcc231017b8f814c80", null ],
    [ "PROIETTILE_CHAR", "menu_8c.html#ab868cca6903d959936689925bd18f478", null ],
    [ "TIMEOUT_VALUE", "menu_8c.html#a244ef94c7189373fc6959985376688ab", null ],
    [ "VELOCITA_PROIETTILE", "menu_8c.html#a867365e8704ef509bf175ea4381052d5", null ],
    [ "disegnaMenu", "menu_8c.html#a8b242ccd86b9e1e347fb62f3eba443d8", null ]
];