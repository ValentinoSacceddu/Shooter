var ostacoli_8c =
[
    [ "ALTEZZA", "ostacoli_8c.html#a737f1e0014465787871b62d0e61129d8", null ],
    [ "LARGHEZZA", "ostacoli_8c.html#accf70613e15dd3bcc231017b8f814c80", null ],
    [ "PROIETTILE_CHAR", "ostacoli_8c.html#ab868cca6903d959936689925bd18f478", null ],
    [ "TIMEOUT_VALUE", "ostacoli_8c.html#a244ef94c7189373fc6959985376688ab", null ],
    [ "VELOCITA_PROIETTILE", "ostacoli_8c.html#a867365e8704ef509bf175ea4381052d5", null ],
    [ "disegnaCasa", "ostacoli_8c.html#adc80ef3ea3bbb2283db14a232dca04f5", null ],
    [ "disegnaCasaPlayer", "ostacoli_8c.html#a4711ac1e8b2dd54cc4a0976f61d51c12", null ],
    [ "disegnaOstacoli", "ostacoli_8c.html#a045ec4d4d3dc0533ed05699109bea03e", null ]
];