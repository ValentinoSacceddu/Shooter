var main_8c =
[
    [ "ALTEZZA", "main_8c.html#a737f1e0014465787871b62d0e61129d8", null ],
    [ "LARGHEZZA", "main_8c.html#accf70613e15dd3bcc231017b8f814c80", null ],
    [ "PROIETTILE_CHAR", "main_8c.html#ab868cca6903d959936689925bd18f478", null ],
    [ "TIMEOUT_VALUE", "main_8c.html#a244ef94c7189373fc6959985376688ab", null ],
    [ "VELOCITA_PROIETTILE", "main_8c.html#a867365e8704ef509bf175ea4381052d5", null ],
    [ "main", "main_8c.html#ae66f6b31b5ad750f1fe042a706a4e3d4", null ]
];